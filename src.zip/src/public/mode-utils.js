/**
 * ModeUtils - модуль для определения режима отображения
 * ES Module version
 */

const doc = typeof document !== 'undefined' ? document : null;
const docElement = doc ? doc.documentElement : null;

// Breakpoints для адаптивности
const BREAKPOINTS = {
  MOBILE_MAX: 767,
  TABLET_MIN: 768,
  TABLET_MAX: 899,
  DESKTOP_MIN: 900,
  DESKTOP_MAX: 1279,
  DESKTOP_WIDE_MIN: 1280
};

function isNumber(value) {
  return typeof value === 'number' && isFinite(value);
}

function getMatchMediaResult(win, query) {
  if (!win || typeof win.matchMedia !== 'function') {
    return false;
  }
  try {
    return win.matchMedia(query).matches;
  } catch (error) {
    return false;
  }
}

function detectInputType(win) {
  const host = win || window;
  const hasCoarsePointer = getMatchMediaResult(host, '(any-pointer: coarse)');
  const navigatorObject = host && host.navigator ? host.navigator : null;
  const maxTouchPoints = navigatorObject && typeof navigatorObject.maxTouchPoints === 'number'
    ? navigatorObject.maxTouchPoints
    : 0;
  const hasTouchPoints = maxTouchPoints > 0;

  return hasCoarsePointer || hasTouchPoints ? 'touch' : 'pointer';
}

function classifyMode(width, inputType) {
  const isTouchDevice = inputType === 'touch';

  if (isTouchDevice) {
    if (width < BREAKPOINTS.TABLET_MIN) {
      return 'mobile';
    }
    if (width < BREAKPOINTS.DESKTOP_MIN) {
      return 'tablet';
    }
    return 'desktop';
  }

  if (width < BREAKPOINTS.TABLET_MIN) {
    return 'mobile';
  }
  if (width < BREAKPOINTS.DESKTOP_MIN) {
    return 'tablet';
  }
  if (width < BREAKPOINTS.DESKTOP_WIDE_MIN) {
    return 'desktop';
  }
  return 'desktop-wide';
}

function collectWidthSources(win, element) {
  const host = win || window;
  const el = element || docElement;

  return [
    {
      source: 'visualViewportWidth',
      value: host && host.visualViewport && isNumber(host.visualViewport.width) && host.visualViewport.width > 0
        ? host.visualViewport.width
        : null,
    },
    {
      source: 'rootClientWidth',
      value: el && isNumber(el.clientWidth) && el.clientWidth > 0 ? el.clientWidth : null,
    },
    {
      source: 'innerWidth',
      value: host && isNumber(host.innerWidth) && host.innerWidth > 0 ? host.innerWidth : null,
    },
    {
      source: 'outerWidth',
      value: host && isNumber(host.outerWidth) && host.outerWidth > 0 ? host.outerWidth : null,
    },
    {
      source: 'screenWidth',
      value: host && host.screen && isNumber(host.screen.width) && host.screen.width > 0 ? host.screen.width : null,
    },
  ];
}

function detectModeInternal(win, element, inputType) {
  const host = win || window;
  const el = element || docElement;
  const sources = collectWidthSources(host, el);

  for (let i = 0; i < sources.length; i += 1) {
    const entry = sources[i];
    const value = entry ? entry.value : null;
    if (isNumber(value) && value > 0) {
      return classifyMode(value, inputType);
    }
  }

  const fallbackQueries = [
    ['mobile', '(max-width: 767px)'],
    ['tablet', '(min-width: 768px) and (max-width: 899px)'],
    ['desktop', '(min-width: 900px) and (max-width: 1279px)'],
    ['desktop-wide', '(min-width: 1280px)'],
  ];

  for (let j = 0; j < fallbackQueries.length; j += 1) {
    const pair = fallbackQueries[j];
    if (getMatchMediaResult(host, pair[1])) {
      return pair[0];
    }
  }

  return 'desktop';
}

function detectInitialState(win, docObject) {
  const host = win || window;
  const documentObject = docObject || doc;
  const element = documentObject && documentObject.documentElement ? documentObject.documentElement : docElement;
  let width = null;

  if (host && isNumber(host.innerWidth) && host.innerWidth > 0) {
    width = host.innerWidth;
  } else if (element && isNumber(element.clientWidth) && element.clientWidth > 0) {
    width = element.clientWidth;
  }

  const inputType = detectInputType(host);
  let mode = 'desktop';

  if (isNumber(width) && width > 0) {
    mode = classifyMode(width, inputType);
  } else {
    mode = detectModeInternal(host, element, inputType);
  }

  return {
    mode: mode,
    input: inputType,
  };
}

function applyModeToBody(docObject, mode) {
  const documentObject = docObject || doc;
  if (!documentObject || !documentObject.body) {
    return false;
  }
  documentObject.body.dataset.mode = mode;
  return true;
}

function applyStateToBody(docObject, state) {
  const documentObject = docObject || doc;
  if (!documentObject || !documentObject.body || !state) {
    return false;
  }

  const bodyElement = documentObject.body;

  if (state.mode) {
    bodyElement.dataset.mode = state.mode;
  }

  if (state.input) {
    bodyElement.dataset.input = state.input;
  }

  return true;
}

// Public API
export const ModeUtils = {
  BREAKPOINTS,
  classifyMode: (width, inputType) => classifyMode(width, inputType),
  detectInput: (win) => detectInputType(win || window),
  detectMode: (win, element, inputType) => detectModeInternal(win || window, element || docElement, inputType),
  getWidthSources: (win, element) => collectWidthSources(win || window, element || docElement),
  detectInitialState: (win, docObject) => detectInitialState(win || window, docObject || doc),
  applyModeToBody: (docObject, mode) => applyModeToBody(docObject || doc, mode),
  applyStateToBody: (docObject, state) => applyStateToBody(docObject || doc, state),
};

// Also expose to window for inline scripts
if (typeof window !== 'undefined') {
  window.ModeUtils = ModeUtils;
}

export default ModeUtils;
